package Compute;

public interface Task<T>{
   T execute();

}
